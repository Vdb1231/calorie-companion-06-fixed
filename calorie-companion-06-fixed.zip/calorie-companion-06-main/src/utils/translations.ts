
import { Language } from "@/contexts/LanguageContext";
import { translations } from "@/translations";

export { translations };
export type { TranslationKey } from "@/translations";
