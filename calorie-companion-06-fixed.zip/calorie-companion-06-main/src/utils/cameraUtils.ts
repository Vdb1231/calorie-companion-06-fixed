
/**
 * Utility functions for camera access and image capture
 */

/**
 * Requests access to the user's camera and starts the video stream
 */
export const startCamera = async (videoRef: React.RefObject<HTMLVideoElement>): Promise<void> => {
  try {
    if (!videoRef.current) {
      throw new Error('Video element not found');
    }

    const stream = await navigator.mediaDevices.getUserMedia({
      video: {
        facingMode: 'environment', // Use back camera on mobile devices
        width: { ideal: 1280 },
        height: { ideal: 720 }
      }
    });
    
    videoRef.current.srcObject = stream;
  } catch (error) {
    console.error('Error accessing camera:', error);
    throw new Error('Could not access camera. Please ensure you have granted camera permissions.');
  }
};

/**
 * Stops the video stream
 */
export const stopCamera = (videoRef: React.RefObject<HTMLVideoElement>): void => {
  if (!videoRef.current || !videoRef.current.srcObject) return;
  
  const stream = videoRef.current.srcObject as MediaStream;
  stream.getTracks().forEach(track => track.stop());
  videoRef.current.srcObject = null;
};

/**
 * Takes a photo from the video feed and displays it in the image element
 */
export const takePhoto = (
  videoRef: React.RefObject<HTMLVideoElement>, 
  canvasRef: React.RefObject<HTMLCanvasElement>,
  photoRef: React.RefObject<HTMLImageElement>
): void => {
  if (!videoRef.current || !canvasRef.current || !photoRef.current) {
    throw new Error('Required elements not found');
  }
  
  const video = videoRef.current;
  const canvas = canvasRef.current;
  const photo = photoRef.current;
  
  // Set canvas dimensions to match video
  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  
  // Draw the current video frame to the canvas
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Could not get canvas context');
  
  ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
  
  // Convert the canvas to a data URL and set it as the image source
  photo.src = canvas.toDataURL('image/jpeg');
};

/**
 * Captures a frame from a video element and returns it as a Blob
 */
export const captureImage = (videoElement: HTMLVideoElement): Promise<Blob> => {
  return new Promise((resolve) => {
    const canvas = document.createElement('canvas');
    canvas.width = videoElement.videoWidth;
    canvas.height = videoElement.videoHeight;
    
    // Draw the current video frame to the canvas
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Could not get canvas context');
    
    ctx.drawImage(videoElement, 0, 0, canvas.width, canvas.height);
    
    // Convert the canvas to a blob
    canvas.toBlob((blob) => {
      if (!blob) throw new Error('Could not create image blob');
      resolve(blob);
    }, 'image/jpeg', 0.9);
  });
};
