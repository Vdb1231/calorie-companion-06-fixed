
import RecipeCarousel from './recipeCarousel/RecipeCarousel';

export default RecipeCarousel;
