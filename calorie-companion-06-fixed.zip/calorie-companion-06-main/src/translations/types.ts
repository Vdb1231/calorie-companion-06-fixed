
import { Language } from "@/contexts/LanguageContext";

export interface TranslationRecord {
  // Navigation
  home: string;
  dashboard: string;
  meals: string;
  chat: string;
  back_to_home: string;
  
  // Home page sections
  features: string;
  how_it_works: string;
  testimonials: string;
  recipe_ideas: string;
  boost_protein: string;
  previous_recipe: string;
  next_recipe: string;
  
  // Hero section
  hero_title: string;
  hero_subtitle: string;
  start_tracking: string;
  watch_demo: string;
  no_credit_card: string;
  cancel_anytime: string;
  
  // Features
  ai_powered: string;
  three_steps: string;
  describe_meal: string;
  describe_meal_desc: string;
  ai_analysis: string;
  ai_analysis_desc: string;
  track_learn: string;
  track_learn_desc: string;
  transform_tracking: string;
  join_users: string;
  start_trial: string;
  
  // Feature cards
  instant_meal_analysis: string;
  instant_meal_analysis_desc: string;
  visualized_progress: string;
  visualized_progress_desc: string;
  nutrition_assistant_title: string;
  nutrition_assistant_desc: string;
  real_time_updates: string;
  real_time_updates_desc: string;
  protein_optimization: string;
  protein_optimization_desc: string;
  nutritional_guidance: string;
  nutritional_guidance_desc: string;
  
  // Dashboard
  dashboard_title: string;
  dashboard_subtitle: string;
  daily_calories: string;
  weekly_average: string;
  protein_goal: string;
  meals_logged: string;
  from_target: string;
  calories_per_day: string;
  of_target: string;
  this_week: string;
  weekly_calorie_intake: string;
  macro_distribution: string;
  macro_nutrients: string;
  daily_macro_goals: string;
  weekly_nutrient_averages: string;
  weekly_nutrition_summary: string;
  day: string;
  calories: string;
  protein: string;
  carbs: string;
  fat: string;
  average: string;
  fiber: string;
  calcium: string;
  iron: string;
  vitamin_c: string;
  
  // Chat
  nutrition_assistant: string;
  powered_by: string;
  ask_about_nutrition: string;
  suggested_questions: string;
  using_meal_history: string;
  reset_conversation: string;
  thinking: string;
  get_personalized_advice: string;
  
  // Food Scanner
  food_scanner: string;
  scan_food: string;
  scanning_instructions: string;
  start_camera: string;
  take_photo: string;
  retake: string;
  analyze_food: string;
  analyzing: string;
  analysis_complete: string;
  camera_access_failed: string;
  capture_failed: string;
  analysis_failed: string;
  
  // Error pages
  page_not_found: string;
  error_occurred: string;
  try_again: string;
  
  // Recipe components
  how_to_make_it: string;
  ingredients: string;
  instructions: string;
  preparation_time: string;
  cooking_time: string;
  servings: string;
  min: string;
  
  // Recipe titles, descriptions, etc.
  recipe_1_title: string;
  recipe_1_desc: string;
  recipe_1_prep: string;
  recipe_1_cook: string;
  recipe_1_servings: string;
  recipe_1_calories: string;
  recipe_1_protein: string;
  
  recipe_2_title: string;
  recipe_2_desc: string;
  recipe_2_prep: string;
  recipe_2_cook: string;
  recipe_2_servings: string;
  recipe_2_calories: string;
  recipe_2_protein: string;
  
  recipe_3_title: string;
  recipe_3_desc: string;
  recipe_3_prep: string;
  recipe_3_cook: string;
  recipe_3_servings: string;
  recipe_3_calories: string;
  recipe_3_protein: string;
  
  recipe_4_title: string;
  recipe_4_desc: string;
  recipe_4_prep: string;
  recipe_4_cook: string;
  recipe_4_servings: string;
  recipe_4_calories: string;
  recipe_4_protein: string;
  
  recipe_5_title: string;
  recipe_5_desc: string;
  recipe_5_prep: string;
  recipe_5_cook: string;
  recipe_5_servings: string;
  recipe_5_calories: string;
  recipe_5_protein: string;
  
  recipe_6_title: string;
  recipe_6_desc: string;
  recipe_6_prep: string;
  recipe_6_cook: string;
  recipe_6_servings: string;
  recipe_6_calories: string;
  recipe_6_protein: string;
  
  recipe_7_title: string;
  recipe_7_desc: string;
  recipe_7_prep: string;
  recipe_7_cook: string;
  recipe_7_servings: string;
  recipe_7_calories: string;
  recipe_7_protein: string;
  
  recipe_8_title: string;
  recipe_8_desc: string;
  recipe_8_prep: string;
  recipe_8_cook: string;
  recipe_8_servings: string;
  recipe_8_calories: string;
  recipe_8_protein: string;
  
  recipe_9_title: string;
  recipe_9_desc: string;
  recipe_9_prep: string;
  recipe_9_cook: string;
  recipe_9_servings: string;
  recipe_9_calories: string;
  recipe_9_protein: string;
  
  recipe_10_title: string;
  recipe_10_desc: string;
  recipe_10_prep: string;
  recipe_10_cook: string;
  recipe_10_servings: string;
  recipe_10_calories: string;
  recipe_10_protein: string;
  
  recipe_11_title: string;
  recipe_11_desc: string;
  recipe_11_prep: string;
  recipe_11_cook: string;
  recipe_11_servings: string;
  recipe_11_calories: string;
  recipe_11_protein: string;
  
  recipe_12_title: string;
  recipe_12_desc: string;
  recipe_12_prep: string;
  recipe_12_cook: string;
  recipe_12_servings: string;
  recipe_12_calories: string;
  recipe_12_protein: string;
  
  recipe_13_title: string;
  recipe_13_desc: string;
  recipe_13_prep: string;
  recipe_13_cook: string;
  recipe_13_servings: string;
  recipe_13_calories: string;
  recipe_13_protein: string;
  
  recipe_14_title: string;
  recipe_14_desc: string;
  recipe_14_prep: string;
  recipe_14_cook: string;
  recipe_14_servings: string;
  recipe_14_calories: string;
  recipe_14_protein: string;
  
  recipe_15_title: string;
  recipe_15_desc: string;
  recipe_15_prep: string;
  recipe_15_cook: string;
  recipe_15_servings: string;
  recipe_15_calories: string;
  recipe_15_protein: string;
  
  recipe_16_title: string;
  recipe_16_desc: string;
  recipe_16_prep: string;
  recipe_16_cook: string;
  recipe_16_servings: string;
  recipe_16_calories: string;
  recipe_16_protein: string;
  
  recipe_17_title: string;
  recipe_17_desc: string;
  recipe_17_prep: string;
  recipe_17_cook: string;
  recipe_17_servings: string;
  recipe_17_calories: string;
  recipe_17_protein: string;
  
  recipe_18_title: string;
  recipe_18_desc: string;
  recipe_18_prep: string;
  recipe_18_cook: string;
  recipe_18_servings: string;
  recipe_18_calories: string;
  recipe_18_protein: string;
  
  recipe_19_title: string;
  recipe_19_desc: string;
  recipe_19_prep: string;
  recipe_19_cook: string;
  recipe_19_servings: string;
  recipe_19_calories: string;
  recipe_19_protein: string;
  
  recipe_20_title: string;
  recipe_20_desc: string;
  recipe_20_prep: string;
  recipe_20_cook: string;
  recipe_20_servings: string;
  recipe_20_calories: string;
  recipe_20_protein: string;
  
  recipe_21_title: string;
  recipe_21_desc: string;
  recipe_21_prep: string;
  recipe_21_cook: string;
  recipe_21_servings: string;
  recipe_21_calories: string;
  recipe_21_protein: string;
  
  recipe_22_title: string;
  recipe_22_desc: string;
  recipe_22_prep: string;
  recipe_22_cook: string;
  recipe_22_servings: string;
  recipe_22_calories: string;
  recipe_22_protein: string;
  
  recipe_23_title: string;
  recipe_23_desc: string;
  recipe_23_prep: string;
  recipe_23_cook: string;
  recipe_23_servings: string;
  recipe_23_calories: string;
  recipe_23_protein: string;
  
  recipe_24_title: string;
  recipe_24_desc: string;
  recipe_24_prep: string;
  recipe_24_cook: string;
  recipe_24_servings: string;
  recipe_24_calories: string;
  recipe_24_protein: string;
  
  recipe_25_title: string;
  recipe_25_desc: string;
  recipe_25_prep: string;
  recipe_25_cook: string;
  recipe_25_servings: string;
  recipe_25_calories: string;
  recipe_25_protein: string;
  
  recipe_26_title: string;
  recipe_26_desc: string;
  recipe_26_prep: string;
  recipe_26_cook: string;
  recipe_26_servings: string;
  recipe_26_calories: string;
  recipe_26_protein: string;
  
  recipe_27_title: string;
  recipe_27_desc: string;
  recipe_27_prep: string;
  recipe_27_cook: string;
  recipe_27_servings: string;
  recipe_27_calories: string;
  recipe_27_protein: string;
  
  recipe_28_title: string;
  recipe_28_desc: string;
  recipe_28_prep: string;
  recipe_28_cook: string;
  recipe_28_servings: string;
  recipe_28_calories: string;
  recipe_28_protein: string;
  
  recipe_29_title: string;
  recipe_29_desc: string;
  recipe_29_prep: string;
  recipe_29_cook: string;
  recipe_29_servings: string;
  recipe_29_calories: string;
  recipe_29_protein: string;
  
  recipe_30_title: string;
  recipe_30_desc: string;
  recipe_30_prep: string;
  recipe_30_cook: string;
  recipe_30_servings: string;
  recipe_30_calories: string;
  recipe_30_protein: string;
  
  recipe_31_title: string;
  recipe_31_desc: string;
  recipe_31_prep: string;
  recipe_31_cook: string;
  recipe_31_servings: string;
  recipe_31_calories: string;
  recipe_31_protein: string;
  
  recipe_32_title: string;
  recipe_32_desc: string;
  recipe_32_prep: string;
  recipe_32_cook: string;
  recipe_32_servings: string;
  recipe_32_calories: string;
  recipe_32_protein: string;
  
  recipe_33_title: string;
  recipe_33_desc: string;
  recipe_33_prep: string;
  recipe_33_cook: string;
  recipe_33_servings: string;
  recipe_33_calories: string;
  recipe_33_protein: string;
  
  recipe_34_title: string;
  recipe_34_desc: string;
  recipe_34_prep: string;
  recipe_34_cook: string;
  recipe_34_servings: string;
  recipe_34_calories: string;
  recipe_34_protein: string;
  
  recipe_35_title: string;
  recipe_35_desc: string;
  recipe_35_prep: string;
  recipe_35_cook: string;
  recipe_35_servings: string;
  recipe_35_calories: string;
  recipe_35_protein: string;
  
  // Legacy recipe keys that still need to be maintained
  recipe_12_ingredients: string;
  recipe_12_instructions: string;
  recipe_13_ingredients: string;
  recipe_13_instructions: string;
  recipe_14_ingredients: string;
  recipe_14_instructions: string;
  recipe_15_ingredients: string;
  recipe_15_instructions: string;
  recipe_16_ingredients: string;
  recipe_16_instructions: string;
  recipe_17_ingredients: string;
  recipe_17_instructions: string;
  recipe_18_ingredients: string;
  recipe_18_instructions: string;
  recipe_19_ingredients: string;
  recipe_19_instructions: string;
  recipe_20_ingredients: string;
  recipe_20_instructions: string;
  recipe_21_ingredients: string;
  recipe_21_instructions: string;
  recipe_22_ingredients: string;
  recipe_22_instructions: string;
  recipe_23_ingredients: string;
  recipe_23_instructions: string;
  recipe_24_ingredients: string;
  recipe_24_instructions: string;
  recipe_25_ingredients: string;
  recipe_25_instructions: string;
  recipe_26_ingredients: string;
  recipe_26_instructions: string;
  recipe_27_ingredients: string;
  recipe_27_instructions: string;
  recipe_28_ingredients: string;
  recipe_28_instructions: string;
  recipe_29_ingredients: string;
  recipe_29_instructions: string;
  recipe_30_ingredients: string;
  recipe_30_instructions: string;
  recipe_31_ingredients: string;
  recipe_31_instructions: string;
  recipe_32_ingredients: string;
  recipe_32_instructions: string;
  recipe_33_ingredients: string;
  recipe_33_instructions: string;
  recipe_34_ingredients: string;
  recipe_34_instructions: string;
  recipe_35_ingredients: string;
  recipe_35_instructions: string;
  
  // Auth related translations
  login: string;
  signup: string;
  logout: string;
  email?: string;
  password?: string;
  forgot_password?: string;
  password_requirements?: string;
  login_successful?: string;
  welcome_back?: string;
  login_failed?: string;
  invalid_credentials?: string;
  signup_successful?: string;
  signup_error?: string;
  signup_failed?: string;
  check_email_for_confirmation?: string;
  already_have_account?: string;
  dont_have_account?: string;
  enter_credentials_to_access?: string;
  create_account_to_start?: string;
  language_changed?: string;
  
  // Language settings
  language?: string;
  language_settings?: string;
  select_language?: string;
  
  // Cooking time
  cooking_time?: string;
}

export type TranslationKey = keyof TranslationRecord;
