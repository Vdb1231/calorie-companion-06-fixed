
import { Language } from "@/contexts/LanguageContext";
import { TranslationKey, TranslationRecord } from './types';
import { en } from './en';
import { bg } from './bg';
import { de } from './de';
import { es } from './es';
import { fr } from './fr';
import { it } from './it';

// Combine all translations
export const translations: Record<Language, TranslationRecord> = {
  en,
  bg,
  de,
  es,
  fr,
  it
};

export type { TranslationKey, TranslationRecord };
export { en, bg, de, es, fr, it };
