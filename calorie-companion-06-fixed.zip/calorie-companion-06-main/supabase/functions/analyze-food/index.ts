
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import "https://deno.land/x/xhr@0.1.0/mod.ts";

const openAIApiKey = Deno.env.get('OPENAI_API_KEY');

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const formData = await req.formData();
    const foodImage = formData.get('image');
    
    if (!foodImage || !(foodImage instanceof File)) {
      return new Response(
        JSON.stringify({ error: 'No image provided or invalid image format' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Received image: ${foodImage.name}, size: ${foodImage.size} bytes`);
    
    // Convert the image file to base64
    const arrayBuffer = await foodImage.arrayBuffer();
    const base64Image = btoa(String.fromCharCode(...new Uint8Array(arrayBuffer)));
    
    // Call OpenAI API
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openAIApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        messages: [
          {
            role: 'system',
            content: `You are a nutritionist specializing in food recognition and nutritional analysis. 
            Analyze the provided image and return ONLY a JSON response with the following structure:
            {
              "foodName": "name of the food",
              "calories": number,
              "protein": number in grams,
              "carbs": number in grams,
              "fat": number in grams,
              "description": "detailed description of the food"
            }
            Do not include explanations or additional text outside the JSON structure.
            If the image does not contain recognizable food, return null for all values except description, which should explain the issue.`
          },
          {
            role: 'user',
            content: [
              { type: 'text', text: 'What food is in this image? Please provide nutritional information.' },
              { type: 'image_url', image_url: { url: `data:image/jpeg;base64,${base64Image}` } }
            ]
          }
        ],
        max_tokens: 800,
      }),
    });

    const data = await response.json();
    console.log('OpenAI response received');
    
    // Parse the response to extract the JSON
    const content = data.choices[0].message.content;
    let nutritionData;
    
    try {
      // Extract JSON from the content if it's not already in JSON format
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        nutritionData = JSON.parse(jsonMatch[0]);
      } else {
        nutritionData = JSON.parse(content);
      }
    } catch (error) {
      console.error('Error parsing nutrition data:', error, 'Content:', content);
      nutritionData = {
        foodName: "Unknown food",
        calories: 0,
        protein: 0,
        carbs: 0,
        fat: 0,
        description: "Could not analyze this image. Please try again with a clearer image of the food."
      };
    }

    return new Response(
      JSON.stringify(nutritionData),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error in analyze-food function:', error);
    return new Response(
      JSON.stringify({ 
        error: 'An error occurred while analyzing the food image',
        details: error.message 
      }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
